package com.parking.system.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.parking.system.Parking;

public class ParkingTest {

	private Parking parking = new Parking();

	@Before
	public void init() {
		parking.createParkingLot(10);
		parking.park("KA-01-HH-1234", "White");
		parking.park("KA-01-HH-9999", "White");
		parking.park("KA-01-BB-0001", "Black");
		parking.park("KA-01-HH-7777", "Red");
		parking.park("KA-01-HH-2701", "Blue");
		parking.park("KA-01-HH-3141", "Green");
	}

	@Test
	public void ParkingLotCreatedTest() {
		// test to check for parking lot.
		Assert.assertTrue(parking.isParkingLotCreated());
	}

	@Test
	public void MaxAvailableSlotsTest() {
		// check for max available slots in parking lots.
		Assert.assertEquals(10, parking.getMaxNumberOfCars());
	}

	@Test
	public void AvailableSlotsListTest() {
		Assert.assertEquals(4, parking.getAvilableParkingSlots().size());
		parking.leave(1);
		Assert.assertEquals(5, parking.getAvilableParkingSlots().size());
		parking.park("KA-01-HH-1234", "White");
	}

	@Test
	public void registrationNumberListTest() {

		Assert.assertEquals(6, parking.getParkedCarsRegistrationNumberList().size());

		// Leaving two cars from parking lot, 2 less car in
		// ParkedCarsRegistrationNumberList validated
		parking.leave(1);
		parking.leave(2);
		Assert.assertEquals(4, parking.getParkedCarsRegistrationNumberList().size());

		// Adding one car in parking lot, 1 more car in ParkedCarsRegistrationNumberList
		// validated
		parking.park("KA-01-HH-9999", "White");
		Assert.assertEquals(5, parking.getParkedCarsRegistrationNumberList().size());

		// Already inserting the same car again, no change in
		// ParkedCarsRegistrationNumberList validated.
		parking.park("KA-01-HH-9999", "White");
		parking.park("KA-01-HH-9999", "White");
		Assert.assertEquals(5, parking.getParkedCarsRegistrationNumberList().size());

		parking.park("KA-01-HH-1234", "White");
		Assert.assertEquals(6, parking.getParkedCarsRegistrationNumberList().size());
	}

	@Test
	public void nearestParkingSlotTest() {
		// check for max available slots in parking lots.
		Assert.assertEquals(7, parking.getNearestParkingSlot());
		parking.leave(4);
		Assert.assertEquals(4, parking.getNearestParkingSlot());
		parking.park("KA-01-HH-7777", "Red");
		parking.park("KA-01-HH-2678", "Purple");
		Assert.assertEquals(8, parking.getNearestParkingSlot());
	}

}
