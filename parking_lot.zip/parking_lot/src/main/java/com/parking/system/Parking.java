package com.parking.system;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Parking {

	private List<Integer> avilableParkingSlots = null;
	private boolean isParkingLotCreated = false;
	private int maxNumberOfCars;
	private List<String> parkedCarsRegistrationNumberList = null;
	private TreeMap<Integer, Car> parkingLot = null;

	public void createParkingLot(int maxNumberOfCars) {

		try {
			if (maxNumberOfCars > 0) {
				this.maxNumberOfCars = maxNumberOfCars;
				this.avilableParkingSlots = new ArrayList<Integer>();
				this.parkedCarsRegistrationNumberList = new ArrayList<String>();
				this.parkingLot = new TreeMap<Integer, Car>();

				for (int i = 1; i <= this.maxNumberOfCars; i++) {
					avilableParkingSlots.add(i);
				}

				System.out.println("Created a parking lot with " + this.maxNumberOfCars + " slots");

				this.isParkingLotCreated = true;

			} else {
				System.out.println("Error creating parking lot. Please enter a positive integer to continue.");
			}
		} catch (Exception e) {
			System.out.println("Error creating parking lot.");
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}

	}

	public List<Integer> getAvilableParkingSlots() {
		return avilableParkingSlots;
	}

	public int getMaxNumberOfCars() {
		return maxNumberOfCars;
	}

	public int getNearestParkingSlot() {
		return this.avilableParkingSlots.get(0);
	}

	public List<String> getParkedCarsRegistrationNumberList() {
		return parkedCarsRegistrationNumberList;
	}

	public TreeMap<Integer, Car> getParkingLot() {
		return parkingLot;
	}

	public boolean isParkingLotCreated() {
		return this.isParkingLotCreated;
	}

	public void leave(int parkingSlotNumber) {

		if (parkingLot.keySet().contains(parkingSlotNumber)) {

			String registrationNumber = this.parkingLot.get(parkingSlotNumber).getRegistrationNumber();
			this.parkingLot.remove(parkingSlotNumber);
			this.parkedCarsRegistrationNumberList
					.remove(this.parkedCarsRegistrationNumberList.indexOf(registrationNumber));
			this.avilableParkingSlots.add(parkingSlotNumber);
			Collections.sort(this.avilableParkingSlots);

			System.out.println("Slot number " + parkingSlotNumber + " is free");

		} else if (parkingSlotNumber < 1) {
			System.out.println("Invalid input, parking slot number cannot be zero or negative.");
		} else if (parkingSlotNumber > maxNumberOfCars) {
			System.out.println("Invalid input, parking slot number beyond capacity.");
		} else {
			System.out.println("Parking slot is already free!");
		}
	}

	public void park(String registrationNumber, String color) {

		if (!parkedCarsRegistrationNumberList.contains(registrationNumber)) {

			if (this.avilableParkingSlots.size() > 0) {

				Car car = new Car(color, registrationNumber);
				int parkingSlotNumber = this.getNearestParkingSlot();
				this.parkedCarsRegistrationNumberList.add(registrationNumber);
				this.avilableParkingSlots.remove(this.avilableParkingSlots.indexOf(parkingSlotNumber));
				parkingLot.put(parkingSlotNumber, car);

				System.out.println("Allocated slot number: " + parkingSlotNumber);

			} else {
				System.out.println("Sorry, parking lot is full.");
			}

		} else {
			System.out.println("Car with registration number : " + registrationNumber + " is already parked.");
		}

	}

	public void registrationNumberForColor(String color) {

		String registrationNumberFound = "";

		for (Map.Entry<Integer, Car> entry : parkingLot.entrySet()) {
			Car parkedCar = entry.getValue();

			if (parkedCar.getColor().equalsIgnoreCase(color)) {
				registrationNumberFound += parkedCar.getRegistrationNumber() + ", ";
			}
		}

		if (registrationNumberFound.length() > 0) {
			registrationNumberFound = registrationNumberFound.substring(0, registrationNumberFound.length() - 2);
			System.out.println(registrationNumberFound);
		} else {
			System.out.println("Not found");
		}

	}

	public void slotNumberForColor(String color) {
		String slotNumberFound = "";

		for (Map.Entry<Integer, Car> entry : parkingLot.entrySet()) {
			Integer parkingSlotNumber = entry.getKey();
			Car parkedCar = entry.getValue();

			if (parkedCar.getColor().equalsIgnoreCase(color)) {
				slotNumberFound += parkingSlotNumber + ", ";
			}
		}
		if (slotNumberFound.length() > 0) {
			slotNumberFound = slotNumberFound.substring(0, slotNumberFound.length() - 2);
			System.out.println(slotNumberFound);
		} else {
			System.out.println("Not Found");
		}
	}

	public void slotNumberForRegistrationNumber(String registrationNumber) {
		String slotNumberFound = "";

		for (Map.Entry<Integer, Car> entry : parkingLot.entrySet()) {
			Integer parkingSlotNumber = entry.getKey();
			Car parkedCar = entry.getValue();

			if (parkedCar.getRegistrationNumber().equalsIgnoreCase(registrationNumber)) {
				slotNumberFound += parkingSlotNumber + ", ";
			}
		}
		if (slotNumberFound.length() > 0) {
			slotNumberFound = slotNumberFound.substring(0, slotNumberFound.length() - 2);
			System.out.println(slotNumberFound);
		} else {
			System.out.println("Not Found");
		}
	}

	public void status() {

		System.out.printf("%-15s %-25s %s%n", "Slot No.", "Registration No.", "Color");

		for (Map.Entry<Integer, Car> entry : parkingLot.entrySet()) {
			Integer parkingSlotNumber = entry.getKey();
			Car parkedCar = entry.getValue();

			System.out.printf("%-15s %-25s %s%n", parkingSlotNumber.toString(), parkedCar.getRegistrationNumber(),
					parkedCar.getColor());
		}
	}

}
