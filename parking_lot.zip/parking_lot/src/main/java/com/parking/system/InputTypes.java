package com.parking.system;

public enum InputTypes {
	create_parking_lot, 
	exit, 
	leave, 
	park, 
	registration_numbers_for_cars_with_colour, 
	slot_number_for_registration_number, 
	slot_numbers_for_cars_with_colour, 
	status
}
