package com.parking.system;

public class Car {

	private String color;
	private String registrationNumber;

	public Car() {
		super();
	}

	public Car(String color, String registrationNumber) {
		super();
		this.color = color;
		this.registrationNumber = registrationNumber;
	}

	public String getColor() {
		return color;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
}
