package com.parking.system;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;

public class Main {

	private static Parking parking = new Parking();

	public static void main(String[] args) {

		boolean exit = false;
		String[] inputArray = null;
		BufferedReader bufferReader = null;
		try {
			if (args.length > 0) {
				bufferReader = new BufferedReader(new FileReader(args[0]));
			}
			while (!exit) {
				if (args.length == 0) {
					bufferReader = new BufferedReader(new InputStreamReader(System.in));
				}

				inputArray = bufferReader.readLine().trim().split("\\s+");

				InputTypes command = InputTypes.valueOf(inputArray[0]);

				switch (command) {

				case create_parking_lot: {

					if (!parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 1) {

							try {
								parking.createParkingLot(Integer.parseInt(inputArray[1]));
							} catch (Exception e) {
								System.out.println("Invalid number passed.");
								System.out.println(e.getClass().getName() + " " + e.getMessage());
							}

						} else {
							System.out.println("Invalid number of inputs passed.\nExample: create_parking_lot 6");
						}

					} else {
						System.out.println("Parking lot already created.");
					}
					break;
				}

				case park: {

					if (parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 2) {
							parking.park(inputArray[1], inputArray[2]);
						} else {
							System.out.println("Invalid input passed.\nExample: park KA-01-HH-1234 White");
						}

					} else {
						System.out.println("Parking lot already created.");
					}

					break;
				}

				case leave: {

					if (parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 1) {
							try {
								parking.leave(Integer.parseInt(inputArray[1]));
							} catch (NumberFormatException e) {
								e.printStackTrace();
							}
						} else {
							System.out.println("Invalid input passed.\nExample: park KA-01-HH-1234 White");
						}

					} else {
						System.out.println("Parking lot already created.");
					}

					break;
				}

				case status: {

					if (parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 0) {

							parking.status();

						} else {
							System.out.println("Invalid input passed.\nExample: status");
						}

					} else {
						System.out.println("Parking lot already created.");
					}

					break;
				}

				case registration_numbers_for_cars_with_colour: {

					if (parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 1) {

							parking.registrationNumberForColor(inputArray[1]);

						} else {
							System.out.println(
									"Invalid input passed.\nExample: registration_numbers_for_cars_with_colour White");
						}

					} else {
						System.out.println("Parking lot already created.");
					}

					break;
				}

				case slot_numbers_for_cars_with_colour: {

					if (parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 1) {

							parking.slotNumberForColor(inputArray[1]);

						} else {
							System.out
									.println("Invalid input passed.\nExample: slot_numbers_for_cars_with_colour White");
						}

					} else {
						System.out.println("Parking lot already created.");
					}

					break;
				}

				case slot_number_for_registration_number: {

					if (parking.isParkingLotCreated()) {

						if ((inputArray.length - 1) == 1) {

							parking.slotNumberForRegistrationNumber(inputArray[1]);

						} else {
							System.out.println(
									"Invalid input passed.\nExample: slot_number_for_registration_number KA-01-HH-3141");
						}

					} else {
						System.out.println("Parking lot already created.");
					}

					break;
				}

				case exit: {
					exit = true;
					break;
				}

				default: {
					System.out.println("Invalid command entered.");
					break;
				}

				}

			}

		} catch (Exception e) {
			System.out.println("Application terminated.");
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}

	}

}
