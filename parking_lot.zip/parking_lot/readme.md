# Parking System

> Parking System implemented as an assignment for GO-JEK!

## Sample Output
![Sample Output](./src/main/resources/images/sample.png)

## Install & Test


### Dependency

1. Java version: 1.8.0_181.
2. Apache Maven 3.5.2

```
$ bin/setup
```
## Usage

### Commands available
```
$ bin/parking_lot

OR

$ bin/parking_lot file_input.txt
```
**Note:** Default branch will be master

***

## License

Built with ♥ by Amar Prakash Pandey([@amarlearning](http://github.com/amarlearning)) under [MIT License](http://amarlearning.mit-license.org/)

You can find a copy of the License at http://amarlearning.mit-license.org/
